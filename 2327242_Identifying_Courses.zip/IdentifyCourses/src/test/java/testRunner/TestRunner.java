package testRunner;

import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;

//@RunWith(Cucumber.class)
@CucumberOptions(
		features= {".//Features/"},
		//features= {".//Features/courses.feature"},
		//features= {".//Features/enterprise.feature"},
		//features= {".//Features/total_languages_and_levels.feature"},

		glue="stepDefinitions",
		plugin= {"pretty","html:reports/myreport.html",
				"com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:",
				"rerun:target/rerun.txt"
		},
		dryRun=false,
		monochrome=true,
		publish=true
		//tags = "@functional"
//		tags = "@smoke"
//		tags = "@regression"
				
		)
public class TestRunner extends AbstractTestNGCucumberTests
 {

}
