package stepDefinitions;


import java.util.Properties;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter;

import factory.BaseClass;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pageObjects.Home_page;
import utilities.ExcelUtility;

public class TC_01_Coursers_Steps {
	
	public WebDriver driver;
	Properties p;
	 Home_page hp;
	 String firstWindow;
	 String[] data;
	 String dataPath=System.getProperty("user.dir")+"\\testData\\OutputData.xlsx";
	 ExcelUtility excel;
	
	@Given("User opens the application with provided URL")
	public void user_opens_the_application_with_provided_url() {
		BaseClass.getLogger().info("Open application with provided URL.........");
    	driver=BaseClass.getDriver();
		hp=new Home_page(driver);
	    excel=new ExcelUtility(dataPath);
	    Assert.assertEquals(hp.homepage(), true);
	    BaseClass.getLogger().info("***** Coursera Home Page Verified *****");
	    ExtentCucumberAdapter.getCurrentStep().log(Status.INFO,"***** Coursera Home Page Verified *****");
	}

	@When("User search for {string} courses and clicks on search button")
	public void user_search_for_courses_and_clicks_on_search_button(String course) {
		BaseClass.getLogger().info("Enter the text('Web development') in search box and click on search button.........");
		hp.enter_text_in_SearchBox(course);
		
		String expSearchResult = "results for \"web development\"";
		String actSearchResult = hp.no_of_courses();
		Assert.assertEquals(actSearchResult.contains(expSearchResult),true );
		BaseClass.getLogger().info("***** Course Search Verified *****");
		ExtentCucumberAdapter.getCurrentStep().log(Status.INFO,"***** Course Search Verified *****");
	}

	@When("select the English Language filter option")
	public void select_the_english_language_filter_option()  {
		BaseClass.getLogger().info("Apply english language filter.........");
		ExtentCucumberAdapter.getCurrentStep().log(Status.INFO,"Apply english language filter.........");
		Assert.assertEquals(hp.select_English_Language().contains("English"),true);
	}

	@When("select the Beginner level filter option")
	public void select_the_beginner_level_filter_option()  {
		BaseClass.getLogger().info("Apply beginner level filter.........");
		ExtentCucumberAdapter.getCurrentStep().log(Status.INFO,"Apply beginner level filter.........");
	   Assert.assertEquals(hp.select_Beginner_Level().contains("Beginner"),true);
	}

	@When("user click on the first course")
	public void user_click_on_the_first_course() {
		BaseClass.getLogger().info("The list of courses will appear.........");
		BaseClass.getLogger().info("Click on the first course.........");
		ExtentCucumberAdapter.getCurrentStep().log(Status.INFO,"The list of courses will appear then Click on the first course");
		hp.click_On_First_Course();
	}

	@Then("user should naviagate to new window for first course")
	public void user_should_naviagate_to_new_window_for_first_course() {
		BaseClass.getLogger().info("Navigate to new window for first course.........");
		ExtentCucumberAdapter.getCurrentStep().log(Status.INFO,"Navigate to new window for first course.........");
		for (String windowHandle : driver.getWindowHandles()) {
		    if(!hp.originalWindow.equals(windowHandle)) {
		        driver.switchTo().window(windowHandle);
		        firstWindow=driver.getWindowHandle();
		        break;
		    }
		}
	}

	@Then("Collect the title,rating and duration of course in hours")
	public void collect_the_title_rating_and_duration_of_course_in_hours() {
		BaseClass.getLogger().info("Collect the details like title,rating,duration of course in hours.........");
		ExtentCucumberAdapter.getCurrentStep().log(Status.INFO,"Collect the details like title,rating,duration of course in hours.........");
	    data=hp.collect_details();
	}

	@Then("add first course data to excel")
	public void add_first_course_data_to_excel() {
		BaseClass.getLogger().info("Store first course data into excel sheet.........");
		ExtentCucumberAdapter.getCurrentStep().log(Status.INFO,"Store first course data into excel sheet.........");
		for(int i=1;i<=3;i++) {
		   excel.writeData(dataPath,"Sheet1", i, 1, data[i-1]);
		}
	}

	@Then("After gathering the data,user should navigate back to parent window from child window")
	public void after_gathering_the_data_user_should_navigate_back_to_parent_window_from_child_window() {
		BaseClass.getLogger().info("Navigate back to parent window from child window.........");
		ExtentCucumberAdapter.getCurrentStep().log(Status.INFO,"Navigate back to parent window from child window.........");
		driver.switchTo().window(hp.originalWindow);
	}

	@When("Now User click on the second course")
	public void now_user_click_on_the_second_course() {
	   BaseClass.getLogger().info("Click on the second course.........");
	   ExtentCucumberAdapter.getCurrentStep().log(Status.INFO,"Click on the second course.........");
	   hp.click_On_second_Course();
	}

	@Then("user should naviagate to new window for second course")
	public void user_should_naviagate_to_new_window_for_second_course() {
		BaseClass.getLogger().info("Navigate to new window for second course.........");
		ExtentCucumberAdapter.getCurrentStep().log(Status.INFO,"Navigate to new window for second course.........");
		for (String windowHandle : driver.getWindowHandles()) {
		    if((!hp.originalWindow.equals(windowHandle)) && (!firstWindow.equals(windowHandle))) {
		        driver.switchTo().window(windowHandle);
		        break;
		    }
		}
	}

	@Then("add second course data to excel")
	public void add_second_course_data_to_excel() {
		BaseClass.getLogger().info("Store second course data into excel sheet.........");
		ExtentCucumberAdapter.getCurrentStep().log(Status.INFO,"Store second course data into excel sheet.........");
		for(int i=1;i<=3;i++) {
			   excel.writeData(dataPath,"Sheet1", i, 2, data[i-1]);
			}
	}


}
