package pageObjects;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import utilities.ExcelUtility;

public class Home_page {
	
	public WebDriver driver;
	 public String originalWindow;
	 public String firstWindow;
	 
	JavascriptExecutor js;
	String path=System.getProperty("user.dir")+"\\testData\\OutputData.xlsx";
	ExcelUtility excelWrite;
	
	public Home_page(WebDriver driver) {

		this.driver = driver;
		 js=(JavascriptExecutor)driver;
		PageFactory.initElements(driver, this);
		originalWindow = driver.getWindowHandle();
		 excelWrite=new ExcelUtility(path);
	}
	
	
	@FindBy(xpath = "//a//img[@class='rc-CourseraLogo']") WebElement coursera;//verify page
	
	@FindBy(xpath = "//div[@class='rc-SearchResultsHeader']//span[1]")WebElement webDevelopment;
	
	
	@FindBy(xpath="//input[@role='textbox']")
	public WebElement searchBox;
	
	@FindBy(xpath="//form[@role='search']//button[@aria-label='Submit Search'][2]")
	public WebElement searchButton;
	
	@FindBy(xpath="//div[@data-testid='search-filter-group-Language']//span[text()='English']")
	public WebElement englishLanguage;
	
	
	@FindBy(xpath="//div[@data-testid='search-filter-group-Level']//span[text()='Beginner']")
	public WebElement beginnerLevel;
	
	
	@FindBy(xpath="//ul[contains(@class,'css-reop')]/li[1]//div[@class='cds-ProductCard-header']/div[2]/a")
			//ul[contains(@class,'css-reop')]/li[1]//div[@class='cds-ProductCard-header']//a")
	public WebElement firstCourse;
	
	@FindBy(xpath="//ul[contains(@class,'css-reop')]/li[2]//div[@class='cds-ProductCard-header']//a")
	public WebElement secondCourse;
	
	@FindBy(xpath="//div[@data-e2e='key-information']//div[contains(@class,'css-guxf')]/div[contains(@class,'Typography')]")
	public WebElement rating1;
	
	@FindBy(xpath="//div[@data-track-component='syllabus']/div/div//span[contains(text(),'hour')]")
	public List<WebElement> hours;
	
	@FindBy(xpath="//h1[@data-e2e='hero-title']")
	public WebElement name;
	
	
	
	@FindBy(xpath="//div[@id='MegamenuWrapperDiv']//span[text()='Explore']")
	public WebElement explore;
	
	@FindBy(xpath="//ul[@class='css-aezbxk']//span[text()='Language Learning']")
	public WebElement language_learning;
	
	@FindBy(xpath="//a[text()='All Language Courses']")
	public WebElement all_langs_courses;
	
	@FindBy(xpath="//h2[contains(text(),'Build Essential')]")
	public WebElement languagePage;
	
	@FindBy(xpath="//div[@data-testid='search-filter-group-Language']//span[text()='Show more']")
	public WebElement show_more_button;
	
	
	@FindBy(xpath="//div[@id='checkbox-group']//div[@class='css-zweepb']//span[contains(@class,'labelContent')]/span")
	public List<WebElement> langs;
	
	@FindBy(xpath="//div[@role='dialog']//span[text()='Close']")
	public WebElement close;
	
	@FindBy(xpath="//div[@data-testid='search-filter-group-Level']//span[contains(@class,'labelContent')]/span")
	public List<WebElement> levels;
	
	public boolean homepage()
	{	
		
		boolean statusHP = coursera.isDisplayed();
		return statusHP;
	}
	
	public void enter_text_in_SearchBox(String course) {
		searchBox.sendKeys(course);
		js.executeScript("arguments[0].click()",searchButton);
		
	}
	
	public String no_of_courses()
	{
		String searchResult = webDevelopment.getText();
		return searchResult;
		
	}
	
	public String select_English_Language() {
		
		js.executeScript("arguments[0].scrollIntoView();",englishLanguage);
		js.executeScript("arguments[0].click()",englishLanguage);
		
		
		return englishLanguage.getText();
	}
	
	
	public String select_Beginner_Level()  {
		
		js.executeScript("arguments[0].scrollIntoView();",beginnerLevel);
		js.executeScript("arguments[0].click()",beginnerLevel);
		
		
		return beginnerLevel.getText();
	}
	
	
	public void click_On_First_Course() {
		
		js.executeScript("arguments[0].scrollIntoView();",firstCourse);
		js.executeScript("arguments[0].click()",firstCourse);

		
		
	}
	
	
	
	
	
	public void click_On_second_Course() {
	
		js.executeScript("arguments[0].click()",secondCourse);

	}
	
	public String[] collect_details() {
		String[] data=new String[3];
		int totalhrs=0;
		String nm=name.getText();
       String  rating=rating1.getText();
        
        for(WebElement h:hours) {
       	 js.executeScript("arguments[0].scrollIntoView();",h);
       	String hr= h.getText();
       	String[] s=hr.split(" ");
       	totalhrs=totalhrs+Integer.parseInt(s[0]);
        }
        data[0]=nm;
        data[1]=rating;
        data[2]=String.valueOf(totalhrs);
       System.out.println("Course Name: "+nm);
       System.out.println("Course Rating: "+rating);
       System.out.println("Duration of course in hours: "+totalhrs);
       return data;
	}
	
	

	
	public void display_languages() {
		Actions act=new Actions(driver);
		act.moveToElement(explore);
		act.moveToElement(language_learning);
		js.executeScript("arguments[0].click()",all_langs_courses);
		js.executeScript("arguments[0].click()",show_more_button);
		
		int cnt =langs.size();
		System.out.println(cnt);
		try {
			excelWrite.write_Data("Sheet2",String.valueOf(cnt),1,0);
		} catch (IOException e) {
			
			e.printStackTrace();
		}
		for(int i=1;i<=langs.size();i++) {
			String lang=langs.get(i-1).getText();
			System.out.println(lang);
			try {
				excelWrite.write_Data("Sheet2",lang,i,1);
			} catch (IOException e) {
				
				e.printStackTrace();
			}
			
		}
		js.executeScript("arguments[0].click()",close);
	}
	
	public void go_to_explore() {
		Actions act=new Actions(driver);
		act.moveToElement(explore);
	}
	
	public void go_to_language_learning() {
		Actions act=new Actions(driver);
		act.moveToElement(language_learning);
		
	}
	
	public void click_on_all_langs_courses() {
		js.executeScript("arguments[0].click()",all_langs_courses);
	}
	
	public String get_Language_Page_heading() {
		String heading=languagePage.getText();
		return heading;
	}
	
	public void click_on_show_more_button() {
		js.executeScript("arguments[0].click()",show_more_button);
	}
	public void click_On_close() {
		js.executeScript("arguments[0].click()",close);
	}
	
	public void display_levels() {
		int cnt =levels.size();
		System.out.println(cnt);
		for(WebElement l:levels) {
			System.out.println(l.getText());
		}
	}
	
	
	
	
	

}
